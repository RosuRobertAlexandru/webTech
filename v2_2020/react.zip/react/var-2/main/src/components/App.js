import React, { Component } from 'react'
import CompanyList from './CompanyList'

class App extends Component {
  render() {
    return (
      <div>
      	A list of robots
      	<CompanyList />
      </div>
    )
  }
}

export default App
